function defaultSections() {
  return [
    {
      id: "favorites",
      title: "Favorites",
      shortcuts: [
        { name: "Gmail", url: "https://mail.google.com" },
        { name: "Drive", url: "https://drive.google.com" },
        { name: "Photos", url: "https://photos.google.com" },
        { name: "Calendar", url: "https://calendar.google.com" }
      ]
    },
    {
      id: "work",
      title: "Work",
      shortcuts: [
        { name: "Notion", url: "https://www.notion.so" },
        { name: "Proton", url: "https://mail.proton.me" },
        { name: "TidyApply", url: "https://tidyapply.app" }
      ]
    },
    {
      id: "messaging",
      title: "Messaging",
      shortcuts: []
    }
  ];
}

const settings = {
  iconSize: "medium",
  sectionStyle: "none",
  background: "#f4f5f7",
  showClock: true,
  openNewTab: false
};

let sections = defaultSections();
let editingId = null;
let pencilTimer = null;

const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const icons = {
  left: "M10 2.5 L4.5 8 L10 13.5",
  right: "M6 2.5 L11.5 8 L6 13.5",
  edit: "M2.5 11.5 L2.5 13.5 L4.5 13.5 L12.5 5.5 L10.5 3.5 Z",
  delete: "M3.5 3.5 L12.5 12.5 M12.5 3.5 L3.5 12.5",
  check: "M3 8.5 L6.5 12 L13 4.5"
};

function formatTime(date) {
  let hours = date.getHours();
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const suffix = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 || 12;
  return hours + ":" + minutes + " " + suffix;
}

function formatDate(date) {
  return days[date.getDay()] + ", " + months[date.getMonth()] + " " + date.getDate();
}

function tick() {
  const now = new Date();
  document.getElementById("clock").textContent = formatTime(now);
  document.getElementById("date").textContent = formatDate(now);
}

function looksLikeUrl(value) {
  const text = value.trim();
  if (!text || /\s/.test(text)) return false;
  if (/^https?:\/\/\S+$/i.test(text)) return true;
  if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?(\/\S*)?$/i.test(text)) return true;
  return /^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/i.test(text);
}

function withProtocol(value) {
  if (/^https?:\/\//i.test(value)) return value;
  return "https://" + value;
}

function openUrl(url) {
  if (settings.openNewTab) {
    window.open(url, "_blank", "noopener");
    return;
  }
  window.location.href = url;
}

function makeIcon(name, size) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 16 16");
  svg.setAttribute("width", String(size));
  svg.setAttribute("height", String(size));
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", icons[name]);
  path.setAttribute("fill", "none");
  path.setAttribute("stroke", "currentColor");
  path.setAttribute("stroke-width", "1.6");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svg.appendChild(path);
  return svg;
}

function savedSections(value) {
  if (!Array.isArray(value) || value.length === 0) return null;
  for (const section of value) {
    if (!section || typeof section.id !== "string" || typeof section.title !== "string" || !Array.isArray(section.shortcuts)) {
      return null;
    }
  }
  return value;
}

function loadStored(stored) {
  const nextSections = savedSections(stored.sections);
  if (nextSections) sections = nextSections;

  const saved = stored.settings;
  if (!saved || typeof saved !== "object") return;
  if (saved.iconSize === "small" || saved.iconSize === "medium" || saved.iconSize === "large") {
    settings.iconSize = saved.iconSize;
  }
  if (saved.sectionStyle === "none" || saved.sectionStyle === "card" || saved.sectionStyle === "outline") {
    settings.sectionStyle = saved.sectionStyle;
  }
  if (typeof saved.background === "string" && /^#[0-9a-fA-F]{6}$/.test(saved.background)) {
    settings.background = saved.background;
  }
  if (typeof saved.showClock === "boolean") settings.showClock = saved.showClock;
  if (typeof saved.openNewTab === "boolean") settings.openNewTab = saved.openNewTab;
}

function persist() {
  chrome.storage.local.set({
    sections: sections.map((section) => ({
      id: section.id,
      title: section.title,
      shortcuts: section.shortcuts.map((shortcut) => ({
        name: shortcut.name,
        url: shortcut.url
      }))
    })),
    settings: {
      iconSize: settings.iconSize,
      sectionStyle: settings.sectionStyle,
      background: settings.background,
      showClock: settings.showClock,
      openNewTab: settings.openNewTab
    }
  });
}

function readTitle() {
  if (!editingId) return;
  const heading = document.querySelector(".group.editing h2");
  const section = sections.find((item) => item.id === editingId);
  if (!heading || !section) return;
  const next = heading.textContent.replace(/\s+/g, " ").trim();
  if (next) section.title = next;
}

function finishEdit() {
  readTitle();
  editingId = null;
  persist();
  renderSections();
}

function startEdit(id) {
  if (editingId === id) return;
  if (editingId) {
    readTitle();
    persist();
  }
  editingId = id;
  renderSections();
  const heading = document.querySelector(".group.editing h2");
  if (heading) heading.focus();
}

function renderSections() {
  clearTimeout(pencilTimer);
  const root = document.getElementById("sections");
  root.replaceChildren();

  sections.forEach((section) => {
    const isEditing = section.id === editingId;
    const group = document.createElement("section");
    group.className = isEditing ? "group editing" : "group";

    const titleRow = document.createElement("div");
    titleRow.className = "title-row";

    const heading = document.createElement("h2");
    heading.textContent = section.title;
    if (isEditing) {
      heading.setAttribute("contenteditable", "true");
      heading.spellcheck = false;
      heading.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          finishEdit();
        }
      });
    }

    const modeBtn = document.createElement("button");
    modeBtn.type = "button";
    modeBtn.className = "mode-btn";
    if (isEditing) {
      modeBtn.setAttribute("aria-label", "Save section");
      modeBtn.appendChild(makeIcon("check", 12));
      modeBtn.addEventListener("click", finishEdit);
    } else {
      modeBtn.hidden = true;
      modeBtn.setAttribute("aria-label", "Edit section");
      modeBtn.appendChild(makeIcon("edit", 12));
      modeBtn.addEventListener("click", () => startEdit(section.id));
      titleRow.addEventListener("mouseenter", () => {
        clearTimeout(pencilTimer);
        pencilTimer = setTimeout(() => {
          modeBtn.hidden = false;
        }, 300);
      });
      titleRow.addEventListener("mouseleave", () => {
        clearTimeout(pencilTimer);
        modeBtn.hidden = true;
      });
    }

    titleRow.append(heading, modeBtn);
    group.appendChild(titleRow);

    const row = document.createElement("div");
    row.className = "tiles";

    section.shortcuts.forEach((shortcut, index) => {
      const tile = document.createElement(isEditing ? "div" : "button");
      tile.className = "tile";
      if (!isEditing) tile.type = "button";

      const avatar = document.createElement("span");
      avatar.className = "avatar";
      avatar.textContent = shortcut.name.trim().charAt(0).toUpperCase() || "?";

      const label = document.createElement("span");
      label.className = "label";
      label.textContent = shortcut.name;

      tile.append(avatar, label);

      if (isEditing) {
        const actions = document.createElement("div");
        actions.className = "tile-actions";
        actions.append(
          shortcutAction("Move left", "left", index === 0, () => moveShortcut(section, index, -1)),
          shortcutAction("Move right", "right", index === section.shortcuts.length - 1, () => moveShortcut(section, index, 1)),
          shortcutAction("Edit", "edit", false, () => editShortcut(section, index)),
          shortcutAction("Delete", "delete", false, () => deleteShortcut(section, index))
        );
        tile.appendChild(actions);
      } else {
        tile.addEventListener("click", () => openUrl(shortcut.url));
      }

      row.appendChild(tile);
    });

    if (isEditing) {
      const add = document.createElement("button");
      add.type = "button";
      add.className = "tile add";
      add.setAttribute("aria-label", "Add shortcut to " + section.title);
      const plus = document.createElement("span");
      plus.className = "avatar";
      plus.textContent = "+";
      add.appendChild(plus);
      add.addEventListener("click", () => addShortcut(section));
      row.appendChild(add);
    }

    group.appendChild(row);
    root.appendChild(group);
  });
}

function shortcutAction(label, icon, disabled, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tile-action";
  button.setAttribute("aria-label", label);
  button.disabled = disabled;
  button.appendChild(makeIcon(icon, 10));
  button.addEventListener("click", onClick);
  return button;
}

function moveShortcut(section, index, direction) {
  const next = index + direction;
  if (next < 0 || next >= section.shortcuts.length) return;
  readTitle();
  const item = section.shortcuts[index];
  section.shortcuts.splice(index, 1);
  section.shortcuts.splice(next, 0, item);
  renderSections();
}

function editShortcut(section, index) {
  readTitle();
  const shortcut = section.shortcuts[index];
  const name = prompt("Shortcut name", shortcut.name);
  if (name === null) return;
  const trimmedName = name.trim();
  if (!trimmedName) return;

  const rawUrl = prompt("Shortcut URL", shortcut.url);
  if (rawUrl === null) return;
  const trimmedUrl = rawUrl.trim();
  if (!trimmedUrl) return;

  shortcut.name = trimmedName;
  shortcut.url = withProtocol(trimmedUrl);
  renderSections();
}

function deleteShortcut(section, index) {
  readTitle();
  section.shortcuts.splice(index, 1);
  renderSections();
}

function addShortcut(section) {
  readTitle();
  const name = prompt("Shortcut name");
  if (name === null) return;
  const trimmedName = name.trim();
  if (!trimmedName) return;

  const rawUrl = prompt("Shortcut URL");
  if (rawUrl === null) return;
  const trimmedUrl = rawUrl.trim();
  if (!trimmedUrl) return;

  section.shortcuts.push({
    name: trimmedName,
    url: withProtocol(trimmedUrl)
  });
  renderSections();
}

function applySettings() {
  document.body.classList.remove("size-small", "size-medium", "size-large");
  document.body.classList.add("size-" + settings.iconSize);
  document.body.classList.remove("style-none", "style-card", "style-outline");
  document.body.classList.add("style-" + settings.sectionStyle);

  document.body.style.backgroundColor = settings.background;
  const red = parseInt(settings.background.slice(1, 3), 16);
  const green = parseInt(settings.background.slice(3, 5), 16);
  const blue = parseInt(settings.background.slice(5, 7), 16);
  const luminance = (0.299 * red + 0.587 * green + 0.114 * blue) / 255;
  document.body.style.color = luminance < 0.55 ? "#f5f5f5" : "#1a1a1a";

  document.getElementById("clock-block").hidden = !settings.showClock;
  document.getElementById("show-clock").checked = settings.showClock;
  document.getElementById("open-new-tab").checked = settings.openNewTab;

  document.querySelectorAll("[data-setting='iconSize'] button").forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.value === settings.iconSize));
  });
  document.querySelectorAll("[data-setting='sectionStyle'] button").forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.value === settings.sectionStyle));
  });
  document.querySelectorAll("#swatches button").forEach((button) => {
    button.style.setProperty("--swatch", button.dataset.color);
    button.setAttribute("aria-pressed", String(button.dataset.color === settings.background));
  });
}

document.getElementById("search-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const query = document.getElementById("query").value.trim();
  if (!query) return;
  if (looksLikeUrl(query)) {
    openUrl(withProtocol(query));
    return;
  }
  openUrl("https://www.google.com/search?q=" + encodeURIComponent(query));
});

document.getElementById("gear").addEventListener("click", () => {
  document.getElementById("settings").hidden = false;
});

document.getElementById("close-settings").addEventListener("click", () => {
  document.getElementById("settings").hidden = true;
});

document.querySelectorAll("[data-setting='iconSize'] button").forEach((button) => {
  button.addEventListener("click", () => {
    settings.iconSize = button.dataset.value;
    applySettings();
    persist();
  });
});

document.querySelectorAll("[data-setting='sectionStyle'] button").forEach((button) => {
  button.addEventListener("click", () => {
    settings.sectionStyle = button.dataset.value;
    applySettings();
    persist();
  });
});

document.querySelectorAll("#swatches button").forEach((button) => {
  button.addEventListener("click", () => {
    settings.background = button.dataset.color;
    applySettings();
    persist();
  });
});

document.getElementById("show-clock").addEventListener("change", (event) => {
  settings.showClock = event.target.checked;
  applySettings();
  persist();
});

document.getElementById("open-new-tab").addEventListener("change", (event) => {
  settings.openNewTab = event.target.checked;
  persist();
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape" || !editingId) return;
  event.preventDefault();
  finishEdit();
});

tick();
setInterval(tick, 1000);

chrome.storage.local.get(["sections", "settings"], (stored) => {
  loadStored(stored || {});
  applySettings();
  renderSections();
});
