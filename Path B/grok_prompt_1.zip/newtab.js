const AVATAR_COLORS = ["#2f5d50", "#3d4f7a", "#8a4b2f", "#5c4d7a", "#3f6b4f", "#7a3f4b"];

const BACKGROUNDS = [
  { id: "sand", color: "#f4f1ea" },
  { id: "paper", color: "#ffffff" },
  { id: "mist", color: "#e8eef2" },
  { id: "sage", color: "#dce8df" },
  { id: "ink", color: "#1c1b18" }
];

const settings = {
  iconSize: "m",
  sectionStyle: "none",
  background: "#f4f1ea",
  showClock: true,
  openInNewTab: false
};

const sections = [
  {
    id: "favorites",
    title: "Favorites",
    tiles: [
      { name: "Gmail", url: "https://mail.google.com" },
      { name: "Drive", url: "https://drive.google.com" },
      { name: "Calendar", url: "https://calendar.google.com" }
    ]
  },
  {
    id: "work",
    title: "Work",
    tiles: [
      { name: "Notion", url: "https://www.notion.so" }
    ]
  },
  {
    id: "messaging",
    title: "Messaging",
    tiles: []
  }
];

const clockBlock = document.getElementById("clock-block");
const clockTime = document.getElementById("clock-time");
const clockDate = document.getElementById("clock-date");
const sectionsEl = document.getElementById("sections");
const overlay = document.getElementById("overlay");
const settingsEl = document.getElementById("settings");
const swatchesEl = document.getElementById("bg-swatches");
const showClockEl = document.getElementById("show-clock");
const openNewTabEl = document.getElementById("open-new-tab");

function letterFor(name) {
  const match = name.trim().match(/[A-Za-z0-9]/);
  return match ? match[0].toUpperCase() : "?";
}

function colorFor(name) {
  let hash = 0;
  for (let i = 0; i < name.length; i += 1) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function looksLikeUrl(value) {
  const text = value.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return true;
  if (/^localhost(:\d+)?([/?#].*)?$/i.test(text)) return true;
  if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?([/?#].*)?$/.test(text)) return true;
  return /^[\w-]+(\.[\w-]+)+([/:?#].*)?$/i.test(text);
}

function toNavigableUrl(value) {
  const text = value.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;
  return `https://${text}`;
}

function normalizeTileUrl(value) {
  const text = value.trim();
  if (!text) return "";
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;
  return `https://${text}`;
}

function openUrl(url) {
  if (settings.openInNewTab) {
    window.open(url, "_blank", "noopener,noreferrer");
    return;
  }
  window.location.href = url;
}

function tickClock() {
  const now = new Date();
  clockTime.textContent = now.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit"
  });
  clockDate.textContent = now.toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric"
  });
}

function renderTiles() {
  sectionsEl.innerHTML = "";
  sections.forEach((section) => {
    const wrap = document.createElement("section");
    wrap.className = "section";

    const title = document.createElement("h2");
    title.className = "section-title";
    title.textContent = section.title;
    wrap.appendChild(title);

    const row = document.createElement("div");
    row.className = "tiles";

    section.tiles.forEach((tile) => {
      const link = document.createElement("a");
      link.className = "tile";
      link.href = tile.url;
      if (settings.openInNewTab) {
        link.target = "_blank";
        link.rel = "noopener noreferrer";
      }
      link.addEventListener("click", (event) => {
        event.preventDefault();
        openUrl(tile.url);
      });

      const avatar = document.createElement("span");
      avatar.className = "avatar";
      avatar.style.background = colorFor(tile.name);
      avatar.textContent = letterFor(tile.name);

      const label = document.createElement("span");
      label.className = "tile-label";
      label.textContent = tile.name;

      link.append(avatar, label);
      row.appendChild(link);
    });

    const add = document.createElement("button");
    add.type = "button";
    add.className = "add-tile";
    add.addEventListener("click", () => addTile(section.id));
    add.innerHTML = '<span class="add-face">+</span><span class="tile-label">Add</span>';
    row.appendChild(add);

    wrap.appendChild(row);
    sectionsEl.appendChild(wrap);
  });
}

function addTile(sectionId) {
  const name = window.prompt("Shortcut name");
  if (name === null) return;
  const trimmedName = name.trim();
  if (!trimmedName) return;

  const url = window.prompt("Shortcut URL");
  if (url === null) return;
  const normalized = normalizeTileUrl(url);
  if (!normalized) return;

  const section = sections.find((item) => item.id === sectionId);
  section.tiles.push({ name: trimmedName, url: normalized });
  renderTiles();
}

function applySettings() {
  document.body.dataset.iconSize = settings.iconSize;
  document.body.dataset.sectionStyle = settings.sectionStyle;
  document.body.style.background = settings.background;
  document.documentElement.style.setProperty("--bg", settings.background);

  const dark = settings.background === "#1c1b18";
  document.body.style.color = dark ? "#f4f1ea" : "#1c1b18";
  document.documentElement.style.setProperty("--ink", dark ? "#f4f1ea" : "#1c1b18");
  document.documentElement.style.setProperty("--muted", dark ? "#b7b2a8" : "#6b675f");
  document.documentElement.style.setProperty("--tile", dark ? "#2a2926" : "#ffffff");
  document.documentElement.style.setProperty("--tile-border", dark ? "#4a4740" : "#d9d4c8");
  document.documentElement.style.setProperty("--panel", dark ? "#2a2926" : "#ffffff");

  clockBlock.classList.toggle("hidden", !settings.showClock);
  showClockEl.checked = settings.showClock;
  openNewTabEl.checked = settings.openInNewTab;

  document.querySelectorAll("[data-icon-size]").forEach((button) => {
    button.classList.toggle("active", button.dataset.iconSize === settings.iconSize);
  });
  document.querySelectorAll("[data-section-style]").forEach((button) => {
    button.classList.toggle("active", button.dataset.sectionStyle === settings.sectionStyle);
  });
  document.querySelectorAll(".swatch").forEach((button) => {
    button.classList.toggle("active", button.dataset.color === settings.background);
  });
}

function openSettings() {
  overlay.classList.remove("hidden");
  settingsEl.classList.remove("hidden");
}

function closeSettings() {
  overlay.classList.add("hidden");
  settingsEl.classList.add("hidden");
}

function renderSwatches() {
  swatchesEl.innerHTML = "";
  BACKGROUNDS.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "swatch";
    button.dataset.color = item.color;
    button.style.background = item.color;
    button.setAttribute("aria-label", item.id.trim());
    button.addEventListener("click", () => {
      settings.background = item.color;
      applySettings();
    });
    swatchesEl.appendChild(button);
  });
}

document.getElementById("search-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const query = document.getElementById("search-input").value.trim();
  if (!query) return;
  if (looksLikeUrl(query)) {
    openUrl(toNavigableUrl(query));
    return;
  }
  openUrl(`https://www.google.com/search?q=${encodeURIComponent(query)}`);
});

document.getElementById("open-settings").addEventListener("click", openSettings);
document.getElementById("close-settings").addEventListener("click", closeSettings);
overlay.addEventListener("click", closeSettings);

document.querySelectorAll("[data-icon-size]").forEach((button) => {
  button.addEventListener("click", () => {
    settings.iconSize = button.dataset.iconSize;
    applySettings();
  });
});

document.querySelectorAll("[data-section-style]").forEach((button) => {
  button.addEventListener("click", () => {
    settings.sectionStyle = button.dataset.sectionStyle;
    applySettings();
  });
});

showClockEl.addEventListener("change", () => {
  settings.showClock = showClockEl.checked;
  applySettings();
});

openNewTabEl.addEventListener("change", () => {
  settings.openInNewTab = openNewTabEl.checked;
  applySettings();
  renderTiles();
});

renderSwatches();
applySettings();
renderTiles();
tickClock();
setInterval(tickClock, 1000);
